#!/usr/bin/env bash
# Dispatch — first-time setup script
# Run from the repo root: bash setup.sh

set -e

GREEN='\033[0;32m'
TEAL='\033[0;36m'
PURPLE='\033[0;35m'
RESET='\033[0m'
BOLD='\033[1m'

echo ""
echo -e "${PURPLE}${BOLD}  ██████╗ ██╗███████╗██████╗  █████╗ ████████╗ ██████╗██╗  ██╗${RESET}"
echo -e "${PURPLE}${BOLD}  ██╔══██╗██║██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██║  ██║${RESET}"
echo -e "${TEAL}${BOLD}  ██║  ██║██║███████╗██████╔╝███████║   ██║   ██║     ███████║${RESET}"
echo -e "${TEAL}${BOLD}  ██║  ██║██║╚════██║██╔═══╝ ██╔══██║   ██║   ██║     ██╔══██║${RESET}"
echo -e "${GREEN}${BOLD}  ██████╔╝██║███████║██║     ██║  ██║   ██║   ╚██████╗██║  ██║${RESET}"
echo ""
echo -e "${BOLD}  Ride-hailing platform setup${RESET}"
echo ""

# ── 1. Frontend dependencies ──────────────────────────────────────────────────
echo -e "${TEAL}[1/5] Installing frontend dependencies...${RESET}"
if command -v pnpm &> /dev/null; then
  pnpm install
else
  npm install
fi

# ── 2. Backend dependencies ───────────────────────────────────────────────────
echo -e "${TEAL}[2/5] Installing backend dependencies...${RESET}"
cd server && npm install && cd ..

# ── 3. Environment files ──────────────────────────────────────────────────────
echo -e "${TEAL}[3/5] Setting up environment files...${RESET}"
if [ ! -f ".env" ]; then
  cp .env.frontend.example .env
  echo -e "${GREEN}  ✓ Created .env from .env.frontend.example${RESET}"
  echo -e "    → Set VITE_API_URL to your Railway backend URL"
else
  echo "  .env already exists, skipping"
fi

if [ ! -f "server/.env" ]; then
  cp server/.env.example server/.env
  echo -e "${GREEN}  ✓ Created server/.env from server/.env.example${RESET}"
  echo -e "    → Fill in DATABASE_URL, JWT secrets, Cloudinary, SMTP"
else
  echo "  server/.env already exists, skipping"
fi

# ── 4. Prisma ─────────────────────────────────────────────────────────────────
echo -e "${TEAL}[4/5] Generating Prisma client...${RESET}"
cd server && npm run db:generate && cd ..
echo -e "${GREEN}  ✓ Prisma client generated${RESET}"

# ── 5. Summary ────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}✅ Setup complete!${RESET}"
echo ""
echo -e "${BOLD}Next steps:${RESET}"
echo ""
echo -e "  1. Edit ${PURPLE}server/.env${RESET} — add DATABASE_URL, JWT_SECRET, Cloudinary, SMTP"
echo -e "  2. Edit ${PURPLE}.env${RESET}        — set VITE_API_URL (or leave blank for local proxy)"
echo ""
echo -e "  ${BOLD}Run locally:${RESET}"
echo -e "    Terminal 1: ${TEAL}cd server && npm run db:push && npm run db:seed && npm run dev${RESET}"
echo -e "    Terminal 2: ${TEAL}npm run dev${RESET}  (or pnpm dev)"
echo ""
echo -e "  ${BOLD}Deploy to Railway:${RESET}"
echo -e "    Push to GitHub → Railway auto-deploys via railway.json"
echo ""
echo -e "  ${BOLD}Build mobile app:${RESET}"
echo -e "    ${TEAL}npm run build && npx cap sync && npx cap open android${RESET}"
echo ""
